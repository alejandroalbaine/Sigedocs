# Contrato del dashboard

El frontend solicita `GET /api/dashboard` con la sesión autenticada. La respuesta debe ser JSON y puede conservar el formato actual. Los campos opcionales permiten que el texto del panel se actualice sin cambiar el frontend.

```json
{
  "cards": [
    { "label": "ACERVO DOCUMENTAL", "title": "Total Documentos Custodiados", "value": 245, "detail": "Actualizado hoy", "icon": "▣", "tone": "blue" }
  ],
  "monthly": {
    "labels": ["Ene", "Feb"],
    "received": [12, 18],
    "registered": [8, 14],
    "period": "Histórico comparativo por tipología — 2026",
    "rate": "+14.2%"
  },
  "status": {
    "labels": ["Vigente", "En revisión"],
    "values": [70, 30],
    "total": 100,
    "totalLabel": "TOTAL TRD",
    "unit": "%"
  },
  "activity": [
    {
      "code": "DOC-001",
      "title": "Plan de estudio",
      "series": "Planes de estudio",
      "unit": "Decanato",
      "responsible": "Nombre Apellido"
    }
  ],
  "alerts": [
    { "type": "danger", "title": "Transferencia próxima", "tag": "3 días", "text": "Descripción breve de la alerta." }
  ]
}
```

`activity` también admite filas en arreglo, en este orden: código, título, serie, unidad y responsable. Los tipos visuales de alerta son `danger`, `warning` e `info`; los tonos de tarjeta disponibles son `blue`, `orange`, `indigo` y `navy`.

El dashboard ya hace búsqueda, paginación y exportación CSV sobre los registros recibidos. No requiere cambios en esos componentes mientras se mantenga este contrato.

## Datos de perfil

El menú de usuario consume `GET /api/auth/me`. Dentro de `user.profile`, el backend puede enviar los siguientes campos opcionales:

```json
{
  "unit": "Gestión Documental Curricular",
  "initials": "AC",
  "photoUrl": "https://servidor-institucional/perfiles/usuario.jpg",
  "joinedAt": "15 de enero de 2024"
}
```

Si `photoUrl` no está disponible, el dashboard muestra `initials`; si tampoco existe, genera las iniciales a partir del nombre. Los datos institucionales son de solo lectura en la interfaz. El guardado permanente de fotografía, contraseña, preferencias y sesiones corresponde a sus respectivos módulos de backend.

### Integraciones pendientes de autenticación

La interfaz del perfil ya contiene los controles para cambiar foto, contraseña y activar autenticación en dos pasos (2FA). El equipo de autenticación debe proporcionar operaciones protegidas para:

- Guardar una fotografía de perfil y devolver su nueva `photoUrl`.
- Verificar la contraseña actual y guardar la contraseña nueva.
- Registrar, confirmar y desactivar 2FA mediante un método institucional aprobado.

Hasta que esas operaciones existan, el dashboard muestra la vista previa local de la foto y mensajes informativos; no afirma que un cambio se haya guardado.
